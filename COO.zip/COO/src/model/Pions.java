package model;

public interface Pions {

	boolean isMoveDiagOk(int xFinal,
            int yFinal);
}
