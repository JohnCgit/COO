package model;

import java.util.List;

public class Echiquier {

	private Jeu jeuBlanc;
	private Jeu jeuNoir;
	private boolean jeuCourant; // true:Blanc & false:Noir
	private static String message;

	public Echiquier() {
		jeuBlanc = new Jeu(Couleur.BLANC);
		jeuNoir = new Jeu(Couleur.NOIR);
		jeuCourant = true;
		message = "D�but de partie!";
	}
	
	
	
	@Override
	public String toString() {
		return "Echiquier [jeuBlanc=" + jeuBlanc + ", jeuNoir=" + jeuNoir + "]";
	}


	private void setMessage(String message) {
		this.message = message;
	}

	public Couleur getColorCurrentPlayer() {
		// TODO Auto-generated method stub
		return jeuCourant?Couleur.BLANC:Couleur.NOIR;
	}

	public static String getMessage() {
		// TODO Auto-generated method stub
		return message;
	}

	public Couleur getPieceColor(int x, int y) {
		// TODO Auto-generated method stub
		Couleur res = null;
		if(jeuBlanc.isPieceHere(x,y)) {
			res=Couleur.BLANC;
		}
		if(jeuNoir.isPieceHere(x,y)) {
			res=Couleur.NOIR;
		}
		return res;
	}

	public Object getPiecesIHM() {
		// TODO Auto-generated method stub
		List<PieceIHM> res = jeuBlanc.getPiecesIHM();
		res.addAll(jeuNoir.getPiecesIHM());
		return res;
	}

	public boolean isEnd() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean isMoveOk(int xInit, int yInit, int xFinal, int yFinal) {
		// TODO Auto-generated method stub
		Couleur couleurPiece = getPieceColor(xInit,yInit);
		boolean res = false;
		if(jeuCourant&&couleurPiece==Couleur.BLANC||!jeuCourant&&couleurPiece==Couleur.NOIR) {
			if(xFinal < 8 && xFinal > -1 && yFinal > -1 && yFinal < 8) {
				if(!(xInit == xFinal && yInit == yFinal)) {
					Jeu jeuC = jeuCourant?jeuBlanc:jeuNoir;
					res = jeuC.isMoveOk(xInit, yInit, xFinal, yFinal);
					if(res) {
						
						Jeu jeunC = !jeuCourant?jeuBlanc:jeuNoir;
						for(Coord coord : jeuC.Path(xInit, yInit, xFinal, yFinal)) {
							if(jeunC.isPieceHere(coord.x, coord.y)) {
								if(coord.x!=xFinal&&coord.y!=yFinal) {
									res=false;
									this.setMessage("KO : la destination est bloqu�e par une pi�ce adverse");
									break;
								}
							}
						}
						
					}
					else {
						this.setMessage("KO : ce mouvement n'est pas possible");
					}
				}
			}
		}
			
		else {
			this.setMessage("KO : c'est au joueur "+ getColorCurrentPlayer()+" de jouer");
		}
		
		return res;
	}

	public boolean move(int xInit, int yInit, int xFinal, int yFinal) {
		// TODO Auto-generated method stub
		boolean res=false;
		res=jeuCourant?jeuBlanc.move(xInit, yInit, xFinal, yFinal):jeuNoir.move(xInit, yInit, xFinal, yFinal);
		if(res) {
			Jeu jeunC = !jeuCourant?jeuBlanc:jeuNoir;
			if(jeunC.isPieceHere(xFinal, yFinal)) {
				jeunC.capture(xFinal, yFinal);
				this.setMessage("OK : deplacement + capture ");
			}
			else {
				this.setMessage("OK : deplacement simple");
			}
		}
		return res;
	}

	public void switchJoueur() {
		// TODO Auto-generated method stub
		jeuCourant=!jeuCourant;
	}
	
	public static void main(String[] args) {
		Echiquier jeu = new Echiquier();
		jeu.move(4, 6, 4, 5);
		System.out.println(jeu.getMessage());
		jeu.move(5, 7, 3, 5);
		System.out.println(jeu.getMessage());
		System.out.println(jeu.isMoveOk(3, 5, 7, 1));
		System.out.println(jeu.getMessage());
		jeu.move(3, 5, 7, 1);
		System.out.println(jeu.getMessage());
		
	}

}
