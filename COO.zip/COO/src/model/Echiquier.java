package model;

import java.util.List;

public class Echiquier {

	private Jeu jeuBlanc;
	private Jeu jeuNoir;
	private boolean jeuCourant; // true:Blanc & false:Noir
	private String message;
	
	public Echiquier() {
		jeuBlanc = new Jeu(Couleur.BLANC);
		jeuNoir = new Jeu(Couleur.NOIR);
		jeuCourant = true;
		message = "D�but de partie!";
	}
	
	
	@Override
	public String toString() {
		return "Echiquier [jeuBlanc=" + jeuBlanc + ", jeuNoir=" + jeuNoir + "]";
	}


	private void setMessage(String message) {
		this.message = message;
	}

	public Couleur getColorCurrentPlayer() {
		// TODO Auto-generated method stub
		return jeuCourant?Couleur.BLANC:Couleur.NOIR;
	}

	public String getMessage() {
		// TODO Auto-generated method stub
		return message;
	}

	public Couleur getPieceColor(int x, int y) {
		// TODO Auto-generated method stub
		Couleur res = null;
		if(jeuBlanc.isPieceHere(x,y)) {
			res=Couleur.BLANC;
		}
		if(jeuNoir.isPieceHere(x,y)) {
			res=Couleur.NOIR;
		}
		return res;
	}

	public Object getPiecesIHM() {
		// TODO Auto-generated method stub
		List<PieceIHM> res = jeuBlanc.getPiecesIHM();
		res.addAll(jeuNoir.getPiecesIHM());
		return res;
	}

	public boolean isEnd() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean isMoveOk(int xInit, int yInit, int xFinal, int yFinal) {
		// TODO Auto-generated method stub
		Couleur couleurPiece = getPieceColor(xInit,yInit);
		boolean res = false;
		if(jeuCourant&&couleurPiece==Couleur.BLANC||!jeuCourant&&couleurPiece==Couleur.NOIR) {
			res = jeuCourant?jeuBlanc.isMoveOk(xInit, yInit, xFinal, yFinal):jeuNoir.isMoveOk(xInit, yInit, xFinal, yFinal);
		}
		if(!res) {
			this.setMessage("deplacement interdit");
		}
		return res;
	}

	public boolean move(int xInit, int yInit, int xFinal, int yFinal) {
		// TODO Auto-generated method stub
		boolean res=false;
		if(isMoveOk(xInit, yInit, xFinal, yFinal)) 
		{
			res=jeuCourant?jeuBlanc.move(xInit, yInit, xFinal, yFinal):jeuNoir.move(xInit, yInit, xFinal, yFinal);
			if(res) {
				this.setMessage("deplacement ok");
			}
		}
		return res;
	}

	public void switchJoueur() {
		// TODO Auto-generated method stub
		jeuCourant=!jeuCourant;
	}
	
	public static void main(String[] args) {
		Echiquier jeu = new Echiquier();
		System.out.println(jeu.isMoveOk(0,7,2,6));
	}

}
