package model;

/**
 * @author francoise.perrin
 * Inspiration Jacques SARAYDARYAN, Adrien GUENARD *
 */
public enum Couleur {
	BLANC, NOIR, NOIRBLANC
}
